ICT පාඩම 1 — සම්පූර්ණ 541 ස්ථාපනය කළ හැකි නොබැඳි App

මෙම සංස්කරණයේ Lesson 01 Full Coverage PDF එකේ ප්‍රශ්න 1–541 සම්පූර්ණයෙන් ඇතුළත් කර ඇත.

ස්ථාපනය:
1. මෙම folder එක HTTPS web hosting එකකට upload කරන්න.
2. Android Chrome එකෙන් site එක විවෘත කරන්න.
3. “ස්ථාපනය” / “App එක ස්ථාපනය කරන්න” / “මුල් තිරයට එක් කරන්න” තෝරන්න.
4. පළමු load එකෙන් පසු app එක offline වැඩ කරයි.

Study flow:
• ප්‍රශ්නයක් open කළ විට තත්පර 60 countdown.
• Countdown අතර “උත්තර බලන්න” button එක අක්‍රීයයි.
• 60s පසු “නෝට් එකේ උත්තරය” සහ “මතක උත්තරය” පෙන්වයි.
• “දන්නවා / නැවත බලන්න” status සහ “මගේ සටහන” device එකේ save වේ.
• මෙම v3/541 build එක වෙනම progress storage key එකක් භාවිත කරයි; පැරණි question numbering සමඟ progress වැරදිව මිශ්‍ර නොවේ.

සටහන:
Local HTML file එක browser එකෙන් offline open කළ හැක. Standalone PWA install + service-worker offline cache සඳහා HTTPS අවශ්‍ය වේ.
